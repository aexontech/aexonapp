import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import {
  Camera,
  Video,
  FileText,
  Edit3,
  Download,
  Calendar,
  Hash,
  Stethoscope,
  Activity,
  Image as ImageIcon,
  CheckCircle2,
  X,
  Maximize,
} from 'lucide-react';
import { Session, Capture } from '../types';
import ImageEditor from './ImageEditor';
import SessionFlowNav from './SessionFlowNav';

type TabId = 'media' | 'reports';

interface PatientProfileProps {
  session: Session;
  onBack: () => void;
  onEditReport: (session: Session) => void;
  onViewGallery: (session: Session) => void;
  onUpdateSession?: (session: Session) => void;
}

export default function PatientProfile({
  session,
  onBack,
  onEditReport,
  onViewGallery,
  onUpdateSession,
}: PatientProfileProps) {
  const [activeTab, setActiveTab] = useState<TabId>('media');
  const [mediaFilter, setMediaFilter] = useState<'all' | 'photos' | 'videos'>('all');
  const [selectedMediaIds, setSelectedMediaIds] = useState<string[]>([]);
  const [previewCapture, setPreviewCapture] = useState<Capture | null>(null);
  const [editingCapture, setEditingCapture] = useState<Capture | null>(null);
  const [videoThumbnails, setVideoThumbnails] = useState<Record<string, string>>({});

  // Generate thumbnail dari frame pertama video
  useEffect(() => {
    const videos = session.captures.filter(c => c.type === 'video' && !c.thumbnail);
    if (videos.length === 0) return;

    videos.forEach(capture => {
      const src = capture.url || capture.dataUrl;
      if (!src) return;

      const vid = document.createElement('video');
      vid.muted = true;
      vid.playsInline = true;
      vid.preload = 'auto';
      vid.crossOrigin = 'anonymous';

      vid.addEventListener('loadeddata', () => {
        // Ambil frame pertama (time = 0)
        vid.currentTime = 0;
      }, { once: true });

      vid.addEventListener('seeked', () => {
        try {
          const canvas = document.createElement('canvas');
          canvas.width = 320;
          canvas.height = Math.round(320 * (vid.videoHeight / (vid.videoWidth || 1))) || 200;
          const ctx = canvas.getContext('2d');
          if (ctx && vid.videoWidth > 0) {
            ctx.drawImage(vid, 0, 0, canvas.width, canvas.height);
            const thumb = canvas.toDataURL('image/jpeg', 0.7);
            setVideoThumbnails(prev => ({ ...prev, [capture.id]: thumb }));
          }
        } catch {}
      }, { once: true });

      vid.src = src;
      vid.load();
    });
  }, [session.captures]);

  const handleAnnotationSave = (editedUrl: string, shapes: any[]) => {
    const updated: Session = {
      ...session,
      captures: session.captures.map(c =>
        c.id === editingCapture?.id
          ? { ...c, url: editedUrl, dataUrl: editedUrl, originalUrl: c.originalUrl || c.url || c.dataUrl, shapes }
          : c
      ),
    };
    onUpdateSession?.(updated);
    setEditingCapture(null);
  };

  const patient = session.patient;
  const photoCount = session.captures.filter(c => c.type === 'image' || c.type === 'photo' || !c.type).length;
  const videoCount = session.captures.filter(c => c.type === 'video').length;

  // Kode unik confidential untuk nama file laporan (tanpa data pasien)
  const reportFileCode = (() => {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    // Deterministic hash dari session ID supaya konsisten
    let hash = 0;
    const seed = session.id + session.date.toISOString();
    for (let i = 0; i < seed.length; i++) {
      hash = ((hash << 5) - hash) + seed.charCodeAt(i);
      hash |= 0;
    }
    let code = '';
    let h = Math.abs(hash);
    for (let i = 0; i < 6; i++) {
      code += chars[h % chars.length];
      h = Math.floor(h / chars.length) || (h + 7);
    }
    return code;
  })();

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'Poli': return { bg: '#EFF6FF', color: '#1D4ED8' };
      case 'Kamar Operasi': return { bg: '#FFF7ED', color: '#C2410C' };
      case 'IGD': return { bg: '#FEF2F2', color: '#DC2626' };
      default: return { bg: '#F1F5F9', color: '#64748B' };
    }
  };

  const catStyle = getCategoryColor(patient.category);

  const filteredCaptures = mediaFilter === 'all'
    ? session.captures
    : mediaFilter === 'photos'
      ? session.captures.filter(c => c.type === 'image' || c.type === 'photo' || !c.type)
      : session.captures.filter(c => c.type === 'video');

  const toggleMediaSelect = (id: string) => {
    setSelectedMediaIds(prev =>
      prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]
    );
  };

  const selectAllVisible = () => {
    const allIds = filteredCaptures.map(c => c.id);
    setSelectedMediaIds(prev => {
      const newSet = new Set([...prev, ...allIds]);
      return Array.from(newSet);
    });
  };

  const clearSelection = () => setSelectedMediaIds([]);

  const handleSaveSelected = () => {
    const selected = session.captures.filter(c => selectedMediaIds.includes(c.id));
    selected.forEach((capture, index) => {
      setTimeout(() => {
        const a = document.createElement('a');
        a.href = capture.url || capture.dataUrl || '';
        const ext = capture.type === 'video' ? 'mp4' : 'png';
        a.download = `media_${index + 1}.${ext}`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
      }, index * 300);
    });
  };

  const tabs: { id: TabId; label: string; icon: React.ReactNode }[] = [
    { id: 'media', label: 'Foto & Video', icon: <Camera style={{ width: 15, height: 15 }} /> },
    { id: 'reports', label: 'Laporan', icon: <FileText style={{ width: 15, height: 15 }} /> },
  ];

  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', height: '100%', fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
      <SessionFlowNav
        currentStep="patient-profile"
        onBack={onBack}
        backLabel="Beranda"
        onNext={() => onEditReport(session)}
        nextLabel="Buat laporan"
      />
    <div
      style={{
        flex: 1,
        overflowY: 'auto',
        height: '100%',
        backgroundColor: '#F4F6F8',
        padding: 32,
      }}
      className="custom-scrollbar"
    >

      {/* Patient header card */}
      <div
        style={{
          backgroundColor: '#ffffff',
          borderRadius: 16,
          border: '1px solid #E8ECF1',
          padding: 28,
          marginBottom: 24,
        }}
      >
        <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 24 }}>
          <div style={{ flex: 1 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 16 }}>
              {/* Avatar */}
              <div
                style={{
                  width: 52,
                  height: 52,
                  borderRadius: 14,
                  background: 'linear-gradient(135deg, #0C1E35, #1e3a5c)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  flexShrink: 0,
                }}
              >
                <span
                  style={{
                    color: 'white',
                    fontWeight: 800,
                    fontSize: 16,
                    fontFamily: "'Plus Jakarta Sans', sans-serif",
                  }}
                >
                  {patient.name.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase()}
                </span>
              </div>
              <div>
                <h2
                  style={{
                    fontSize: 24,
                    fontWeight: 900,
                    color: '#0C1E35',
                    lineHeight: 1.2,
                    marginBottom: 4,
                    fontFamily: "'Plus Jakarta Sans', sans-serif",
                  }}
                >
                  {patient.name}
                </h2>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}>
                  <span
                    style={{
                      padding: '2px 8px',
                      backgroundColor: catStyle.bg,
                      color: catStyle.color,
                      fontSize: 11,
                      fontWeight: 700,
                      borderRadius: 6,
                    }}
                  >
                    {patient.category}
                  </span>
                  {patient.diagnosis_icd10 && (
                    <span
                      style={{
                        padding: '2px 8px',
                        backgroundColor: '#EFF6FF',
                        color: '#1D4ED8',
                        fontSize: 11,
                        fontWeight: 700,
                        borderRadius: 6,
                      }}
                    >
                      {patient.diagnosis_icd10.split(' - ')[0]}
                    </span>
                  )}
                </div>
              </div>
            </div>

            {/* Info grid */}
            <div
              style={{
                display: 'grid',
                gridTemplateColumns: 'repeat(2, 1fr)',
                gap: '12px 32px',
              }}
            >
              <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                <Hash style={{ width: 14, height: 14, color: '#94A3B8' }} />
                <div>
                  <p style={{ fontSize: 10, color: '#94A3B8', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.05em', margin: 0 }}>
                    No. RM
                  </p>
                  <p style={{ fontSize: 13, color: '#0C1E35', fontWeight: 600, margin: 0 }}>
                    {patient.rmNumber || '-'}
                  </p>
                </div>
              </div>

              <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                <Calendar style={{ width: 14, height: 14, color: '#94A3B8' }} />
                <div>
                  <p style={{ fontSize: 10, color: '#94A3B8', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.05em', margin: 0 }}>
                    Tanggal Sesi
                  </p>
                  <p style={{ fontSize: 13, color: '#0C1E35', fontWeight: 600, margin: 0 }}>
                    {session.date.toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' })}
                  </p>
                </div>
              </div>

              <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                <Stethoscope style={{ width: 14, height: 14, color: '#94A3B8' }} />
                <div>
                  <p style={{ fontSize: 10, color: '#94A3B8', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.05em', margin: 0 }}>
                    Diagnosis
                  </p>
                  <p style={{ fontSize: 13, color: '#0C1E35', fontWeight: 600, margin: 0 }}>
                    {patient.diagnosis || '-'}
                  </p>
                </div>
              </div>

              <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                <Activity style={{ width: 14, height: 14, color: '#94A3B8' }} />
                <div>
                  <p style={{ fontSize: 10, color: '#94A3B8', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.05em', margin: 0 }}>
                    Prosedur
                  </p>
                  <p style={{ fontSize: 13, color: '#0C1E35', fontWeight: 600, margin: 0 }}>
                    {patient.procedures_icd9?.[0] || patient.procedures?.[0] || '-'}
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Quick stats on the right */}
          <div style={{ display: 'flex', gap: 12, flexShrink: 0 }}>
            <div
              style={{
                backgroundColor: '#F8FAFC',
                borderRadius: 12,
                padding: '14px 20px',
                textAlign: 'center',
                minWidth: 80,
              }}
            >
              <div style={{ fontSize: 24, fontWeight: 800, color: '#0C1E35', fontFamily: "'Plus Jakarta Sans', sans-serif", lineHeight: 1 }}>
                {photoCount}
              </div>
              <div style={{ fontSize: 10, color: '#94A3B8', fontWeight: 600, marginTop: 4 }}>Foto</div>
            </div>
            <div
              style={{
                backgroundColor: '#F8FAFC',
                borderRadius: 12,
                padding: '14px 20px',
                textAlign: 'center',
                minWidth: 80,
              }}
            >
              <div style={{ fontSize: 24, fontWeight: 800, color: '#0C1E35', fontFamily: "'Plus Jakarta Sans', sans-serif", lineHeight: 1 }}>
                {videoCount}
              </div>
              <div style={{ fontSize: 10, color: '#94A3B8', fontWeight: 600, marginTop: 4 }}>Video</div>
            </div>
            <div
              style={{
                backgroundColor: '#F8FAFC',
                borderRadius: 12,
                padding: '14px 20px',
                textAlign: 'center',
                minWidth: 80,
              }}
            >
              <div style={{ fontSize: 24, fontWeight: 800, color: '#0C1E35', fontFamily: "'Plus Jakarta Sans', sans-serif", lineHeight: 1 }}>
                {session.captures.length}
              </div>
              <div style={{ fontSize: 10, color: '#94A3B8', fontWeight: 600, marginTop: 4 }}>Total</div>
            </div>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div style={{ display: 'flex', gap: 4, marginBottom: 20 }}>
        {tabs.map((tab) => {
          const active = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: 6,
                padding: '10px 20px',
                border: 'none',
                borderBottom: active ? '2px solid #0D9488' : '2px solid transparent',
                background: 'none',
                cursor: 'pointer',
                fontSize: 13,
                fontWeight: active ? 700 : 500,
                color: active ? '#0C1E35' : '#94A3B8',
                fontFamily: "'Plus Jakarta Sans', sans-serif",
                transition: 'all 150ms',
              }}
            >
              {tab.icon}
              {tab.label}
            </button>
          );
        })}
      </div>

      {/* Tab content */}
      <motion.div
        key={activeTab}
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.25 }}
      >
        {activeTab === 'media' && (
          <div style={{ backgroundColor: '#ffffff', borderRadius: 14, border: '1px solid #E8ECF1', overflow: 'hidden' }}>
            {/* Header: filter tabs + actions */}
            <div style={{ padding: '14px 20px', borderBottom: '1px solid #F1F5F9', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <div style={{ display: 'flex', borderBottom: '1.5px solid #E8ECF1' }}>
                {([
                  { key: 'all', label: 'Semua', count: session.captures.length },
                  { key: 'photos', label: 'Foto', count: photoCount },
                  { key: 'videos', label: 'Video', count: videoCount },
                ] as const).map(f => {
                  const isActive = mediaFilter === f.key;
                  return (
                    <button key={f.key} onClick={() => setMediaFilter(f.key)}
                      style={{
                        padding: '8px 16px', fontSize: 12, fontWeight: isActive ? 700 : 500,
                        border: 'none', borderBottom: isActive ? '2px solid #0D9488' : '2px solid transparent',
                        cursor: 'pointer', backgroundColor: 'transparent',
                        color: isActive ? '#0C1E35' : '#94A3B8', transition: 'all 150ms',
                        fontFamily: "'Plus Jakarta Sans', sans-serif", marginBottom: '-1.5px',
                        display: 'flex', alignItems: 'center', gap: 5,
                      }}>
                      {f.label}
                      <span style={{ fontSize: 9, fontWeight: 700, backgroundColor: isActive ? '#E6F7F5' : '#F1F5F9', color: isActive ? '#0D9488' : '#94A3B8', padding: '1px 6px', borderRadius: 8 }}>{f.count}</span>
                    </button>
                  );
                })}
              </div>
              <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
                {selectedMediaIds.length > 0 && (
                  <>
                    <span style={{ fontSize: 11, color: '#64748B', fontWeight: 600 }}>{selectedMediaIds.length} dipilih</span>
                    <button onClick={clearSelection}
                      style={{ padding: '5px 10px', fontSize: 11, fontWeight: 600, color: '#94A3B8', background: 'none', border: '1px solid #E8ECF1', borderRadius: 6, cursor: 'pointer', fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
                      Batal
                    </button>
                    <button onClick={handleSaveSelected}
                      style={{ padding: '5px 12px', fontSize: 11, fontWeight: 700, color: '#fff', background: 'linear-gradient(135deg, #0C1E35, #152d4f)', border: 'none', borderRadius: 6, cursor: 'pointer', fontFamily: "'Plus Jakarta Sans', sans-serif", display: 'flex', alignItems: 'center', gap: 4 }}>
                      <Download style={{ width: 12, height: 12 }} /> Simpan
                    </button>
                  </>
                )}
                {selectedMediaIds.length === 0 && filteredCaptures.length > 0 && (
                  <button onClick={selectAllVisible}
                    style={{ padding: '5px 12px', fontSize: 11, fontWeight: 600, color: '#64748B', background: 'none', border: '1px solid #E8ECF1', borderRadius: 6, cursor: 'pointer', fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
                    Pilih Semua
                  </button>
                )}
              </div>
            </div>

            {/* Grid gallery */}
            {filteredCaptures.length === 0 ? (
              <div style={{ padding: '48px 0', textAlign: 'center' }}>
                <Camera style={{ width: 36, height: 36, color: '#E8ECF1', margin: '0 auto 10px', display: 'block' }} />
                <p style={{ fontSize: 13, color: '#94A3B8', fontWeight: 500 }}>Belum ada media</p>
              </div>
            ) : (
              <div style={{ padding: 16, display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(130px, 1fr))', gap: 10 }}>
                {filteredCaptures.map((capture, idx) => {
                  const isSelected = selectedMediaIds.includes(capture.id);
                  return (
                    <div key={capture.id || idx}
                      onClick={() => toggleMediaSelect(capture.id)}
                      onDoubleClick={() => setPreviewCapture(capture)}
                      style={{
                        width: '100%', aspectRatio: '1', borderRadius: 10,
                        backgroundColor: '#F1F5F9', overflow: 'hidden', cursor: 'pointer',
                        position: 'relative', border: isSelected ? '2.5px solid #0D9488' : '2.5px solid transparent',
                        transition: 'border-color 150ms',
                      }}>
                      {capture.type === 'video' ? (
                        (capture.thumbnail || videoThumbnails[capture.id]) ? (
                          <div style={{ width: '100%', height: '100%', position: 'relative' }}>
                            <img src={capture.thumbnail || videoThumbnails[capture.id]} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover', pointerEvents: 'none' }} />
                            <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', pointerEvents: 'none' }}>
                              <div style={{ width: 36, height: 36, borderRadius: '50%', backgroundColor: 'rgba(0,0,0,0.5)', display: 'flex', alignItems: 'center', justifyContent: 'center', backdropFilter: 'blur(4px)' }}>
                                <div style={{ width: 0, height: 0, borderLeft: '12px solid #fff', borderTop: '7px solid transparent', borderBottom: '7px solid transparent', marginLeft: 3 }} />
                              </div>
                            </div>
                          </div>
                        ) : (
                          <div style={{ width: '100%', height: '100%', background: 'linear-gradient(135deg, #0f1623, #1a2a3f)', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 6 }}>
                            <div style={{ width: 40, height: 40, borderRadius: '50%', backgroundColor: 'rgba(255,255,255,0.1)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                              <div style={{ width: 0, height: 0, borderLeft: '14px solid rgba(255,255,255,0.7)', borderTop: '8px solid transparent', borderBottom: '8px solid transparent', marginLeft: 4 }} />
                            </div>
                            <span style={{ fontSize: 9, color: 'rgba(255,255,255,0.4)', fontWeight: 600 }}>VIDEO</span>
                          </div>
                        )
                      ) : (capture.thumbnail || capture.dataUrl || capture.url) ? (
                          <img src={capture.thumbnail || capture.dataUrl || capture.url} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover', pointerEvents: 'none' }} />
                      ) : (
                        <div style={{ width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                          <Camera style={{ width: 24, height: 24, color: '#CBD5E1' }} />
                        </div>
                      )}
                      {/* Select checkbox */}
                      <div style={{
                        position: 'absolute', top: 6, right: 6, width: 22, height: 22, borderRadius: 6,
                        border: isSelected ? 'none' : '2px solid rgba(255,255,255,0.7)',
                        backgroundColor: isSelected ? '#0D9488' : 'rgba(0,0,0,0.2)',
                        display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 10,
                      }}>
                        {isSelected && <CheckCircle2 style={{ width: 14, height: 14, color: '#fff' }} />}
                      </div>
                      {/* Type badge */}
                      {capture.type === 'video' && (
                        <div style={{ position: 'absolute', bottom: 6, left: 6, padding: '2px 6px', backgroundColor: 'rgba(0,0,0,0.6)', borderRadius: 4, display: 'flex', alignItems: 'center', gap: 3 }}>
                          <Video style={{ width: 10, height: 10, color: 'white' }} />
                          <span style={{ fontSize: 9, color: 'white', fontWeight: 600 }}>Video</span>
                        </div>
                      )}
                      {/* Preview + Edit on hover */}
                      <div style={{ position: 'absolute', bottom: 6, right: 6, opacity: 0, transition: 'opacity 150ms', display: 'flex', gap: 4 }}
                        onMouseEnter={e => { e.currentTarget.style.opacity = '1'; }}
                        onMouseLeave={e => { e.currentTarget.style.opacity = '0'; }}>
                        {capture.type !== 'video' && (
                          <button onClick={(e) => { e.stopPropagation(); setEditingCapture(capture); }}
                            title="Anotasi"
                            style={{ width: 28, height: 28, borderRadius: 6, backgroundColor: '#0C1E35', border: 'none', color: '#fff', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', boxShadow: '0 2px 6px rgba(0,0,0,0.3)' }}>
                            <Edit3 style={{ width: 13, height: 13 }} />
                          </button>
                        )}
                        <button onClick={(e) => { e.stopPropagation(); setPreviewCapture(capture); }}
                          title="Preview"
                          style={{ width: 28, height: 28, borderRadius: 6, backgroundColor: 'rgba(0,0,0,0.5)', border: 'none', color: '#fff', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                          <Maximize style={{ width: 14, height: 14 }} />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* Preview modal */}
        {previewCapture && (
          <div style={{ position: 'fixed', inset: 0, zIndex: 110, display: 'flex', alignItems: 'center', justifyContent: 'center', backgroundColor: 'rgba(15,23,42,0.7)', backdropFilter: 'blur(10px)', padding: 40 }}
            onClick={() => setPreviewCapture(null)}>
            <div style={{ position: 'relative', maxWidth: 900, width: '100%', backgroundColor: '#000', borderRadius: 16, overflow: 'hidden', boxShadow: '0 25px 50px rgba(0,0,0,0.3)' }}
              onClick={e => e.stopPropagation()}>
              <div style={{ aspectRatio: '16/10', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                {previewCapture.type === 'video' ? (
                  <video src={previewCapture.url || previewCapture.dataUrl} controls autoPlay muted playsInline
                    style={{ maxWidth: '100%', maxHeight: '100%', objectFit: 'contain' }}
                    onDoubleClick={e => e.stopPropagation()} />
                ) : (
                  <img src={previewCapture.thumbnail || previewCapture.dataUrl || previewCapture.url} alt=""
                    style={{ maxWidth: '100%', maxHeight: '100%', objectFit: 'contain' }} />
                )}
              </div>
              <button onClick={() => setPreviewCapture(null)}
                style={{ position: 'absolute', top: 12, right: 12, width: 36, height: 36, borderRadius: 10, backgroundColor: 'rgba(0,0,0,0.5)', border: 'none', color: '#fff', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <X style={{ width: 18, height: 18 }} />
              </button>
            </div>
          </div>
        )}

        {activeTab === 'reports' && (
          <div
            style={{
              backgroundColor: '#ffffff',
              borderRadius: 14,
              border: '1px solid #E8ECF1',
              overflow: 'hidden',
            }}
          >
            <div
              style={{
                padding: '16px 20px',
                borderBottom: '1px solid #F1F5F9',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
              }}
            >
              <h3 style={{ fontSize: 15, color: '#0C1E35' }}>
                Laporan
              </h3>
              <button
                onClick={() => onEditReport(session)}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: 6,
                  padding: '7px 14px',
                  background: '#0C1E35',
                  color: '#fff',
                  border: 'none',
                  borderRadius: 8,
                  fontSize: 12,
                  fontWeight: 700,
                  cursor: 'pointer',
                  fontFamily: "'Plus Jakarta Sans', sans-serif",
                  transition: 'background 150ms',
                }}
                onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = '#1a3a5c'; }}
                onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = '#0C1E35'; }}
              >
                <Edit3 style={{ width: 14, height: 14 }} />
                Buat / Edit Laporan
              </button>
            </div>

            {/* Report items — placeholder for saved reports */}
            <div style={{ padding: 20 }}>
              <div
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  padding: '14px 16px',
                  backgroundColor: '#F8FAFC',
                  borderRadius: 10,
                  marginBottom: 8,
                }}
              >
                <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                  <div
                    style={{
                      width: 36,
                      height: 36,
                      borderRadius: 8,
                      backgroundColor: '#FEF2F2',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                    }}
                  >
                    <FileText style={{ width: 16, height: 16, color: '#EF4444' }} />
                  </div>
                  <div>
                    <p style={{ fontSize: 13, fontWeight: 600, color: '#0C1E35', margin: 0 }}>
                      RPT_{reportFileCode}_{session.date.toLocaleDateString('id-ID', { day: '2-digit', month: '2-digit', year: 'numeric' }).replace(/\//g, '')}-001.pdf
                    </p>
                    <p style={{ fontSize: 11, color: '#94A3B8', margin: 0, marginTop: 2 }}>
                      {session.date.toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' })}
                    </p>
                  </div>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                  <button
                    onClick={() => onEditReport(session)}
                    title="Edit Laporan"
                    style={{
                      padding: '6px 12px',
                      display: 'flex',
                      alignItems: 'center',
                      gap: 4,
                      backgroundColor: 'transparent',
                      border: '1px solid #E8ECF1',
                      borderRadius: 6,
                      color: '#64748B',
                      fontSize: 11,
                      fontWeight: 600,
                      cursor: 'pointer',
                      fontFamily: "'Plus Jakarta Sans', sans-serif",
                      transition: 'all 150ms',
                    }}
                    onMouseEnter={e => {
                      const t = e.currentTarget as HTMLElement;
                      t.style.borderColor = '#0C1E35';
                      t.style.color = '#0C1E35';
                    }}
                    onMouseLeave={e => {
                      const t = e.currentTarget as HTMLElement;
                      t.style.borderColor = '#E2E8F0';
                      t.style.color = '#64748B';
                    }}
                  >
                    <Edit3 style={{ width: 12, height: 12 }} />
                    Edit
                  </button>
                  <button
                    title="Download PDF"
                    style={{
                      padding: 6,
                      backgroundColor: 'transparent',
                      border: '1px solid #E8ECF1',
                      borderRadius: 6,
                      color: '#64748B',
                      cursor: 'pointer',
                      display: 'flex',
                      transition: 'all 150ms',
                    }}
                    onMouseEnter={e => {
                      const t = e.currentTarget as HTMLElement;
                      t.style.borderColor = '#2563EB';
                      t.style.color = '#2563EB';
                    }}
                    onMouseLeave={e => {
                      const t = e.currentTarget as HTMLElement;
                      t.style.borderColor = '#E2E8F0';
                      t.style.color = '#64748B';
                    }}
                  >
                    <Download style={{ width: 14, height: 14 }} />
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </motion.div>

      {/* Image Editor / Anotasi */}
      {editingCapture && (
        <ImageEditor
          imageUrl={editingCapture.originalUrl || editingCapture.url || editingCapture.dataUrl || ''}
          initialShapes={editingCapture.shapes}
          onSave={handleAnnotationSave}
          onClose={() => setEditingCapture(null)}
        />
      )}
    </div>
    </div>
  );
}